# Funtion is use for re-usability.

def greet(name):
    
    print(f"Hello {name}\nWelcome onboard")
    
greet("philo")