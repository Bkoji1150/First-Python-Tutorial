# Funtion is use for re-usability.

def greet(first_name, last_name):
    """{first_name} {last_name} are all parameter"""
    print(f"Hello {first_name} {last_name}\nWelcome onboard")

"""{Philo}{Bello} are all Arguments """
greet("philo", "Bello") 
greet("Koji", "Bello")